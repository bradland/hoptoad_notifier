module HoptoadNotifier
  VERSION = "2.2.2".freeze
end
