require 'hoptoad_notifier/rails'
